export default {
  table: {
    apiSetting: {
      
      pageField: 'page',
     
      sizeField: 'pageSize',
      
      listField: 'list',
      
      totalField: 'pageCount',
     
      countField: 'itemCount',
    },
    
    defaultPageSize: 10,
    
    pageSizes: [10, 20, 30, 40, 50],
  },
  upload: {
   
    apiSetting: {
      
      infoField: 'data',
      
      imgField: 'photo',
    },
   
    maxSize: 2,
    
    fileType: ['image/png', 'image/jpg', 'image/jpeg', 'image/gif', 'image/svg+xml'],
  },
};
