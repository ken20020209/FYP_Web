export const animates = [
  { value: 'zoom-fade', label: '' },
  { value: 'zoom-out', label: '' },
  { value: 'fade-slide', label: '' },
  { value: 'fade', label: '' },
  { value: 'fade-bottom', label: '' },
  { value: 'fade-scale', label: '' },
];
