import { http } from '@/utils/http/axios';


export function adminMenus() {
  return http.request({
    url: '/menus',
    method: 'GET',
  });
}


export function getMenuList(params?) {
  return http.request({
    url: '/menu/list',
    method: 'GET',
    params,
  });
}
