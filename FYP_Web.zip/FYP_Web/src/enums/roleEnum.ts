export enum RoleEnum {

  ADMIN = 'admin',

  NORMAL = 'normal',
}
