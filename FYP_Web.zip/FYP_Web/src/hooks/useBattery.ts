import { computed, onMounted, reactive, toRefs } from 'vue';

interface Battery {
  charging: boolean; 
  chargingTime: number; 
  dischargingTime: number; 
  level: number; 
  [key: string]: any;
}

export const useBattery = () => {
  const state = reactive({
    battery: {
      charging: false,
      chargingTime: 0,
      dischargingTime: 0,
      level: 100,
    },
  });

  
  const updateBattery = (target) => {
    for (const key in state.battery) {
      state.battery[key] = target[key];
    }
    state.battery.level = state.battery.level * 100;
  };

  
  const calcDischargingTime = computed(() => {
    const hour = state.battery.dischargingTime / 3600;
    const minute = (state.battery.dischargingTime / 60) % 60;
    return `${~~hour}hr${~~minute}min`;
  });

 
  const calcChargingTime = computed(() => {
    console.log(state.battery);
    const hour = state.battery.chargingTime / 3600;
    const minute = (state.battery.chargingTime / 60) % 60;
    return `${~~hour}hr${~~minute}min`;
  });

  
  const batteryStatus = computed(() => {
    if (state.battery.charging && state.battery.level >= 100) {
      return 'Full Charge';
    } else if (state.battery.charging) {
      return 'Charging';
    } else {
      return 'Disconnceted';
    }
  });

  onMounted(async () => {
    const BatteryManager: Battery = await (window.navigator as any).getBattery();
    updateBattery(BatteryManager);

    
    BatteryManager.onchargingchange = ({ target }) => {
      updateBattery(target);
    };
    
    BatteryManager.onchargingtimechange = ({ target }) => {
      updateBattery(target);
    };
    
    BatteryManager.ondischargingtimechange = ({ target }) => {
      updateBattery(target);
    };
   
    BatteryManager.onlevelchange = ({ target }) => {
      updateBattery(target);
    };

    // new Intl.DateTimeFormat('zh', {
    //   year: 'numeric',
    //   month: '2-digit',
    //   day: '2-digit',
    //   hour: '2-digit',
    //   minute: '2-digit',
    //   second: '2-digit',
    //   hour12: false
    // }).format(new Date())
  });

  return {
    ...toRefs(state),
    batteryStatus,
    calcDischargingTime,
    calcChargingTime,
  };
};
