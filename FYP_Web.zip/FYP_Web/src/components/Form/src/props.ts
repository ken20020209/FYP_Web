import type { CSSProperties, PropType } from 'vue';
import { FormSchema } from './types/form';
import type { GridProps, GridItemProps } from 'naive-ui/lib/grid';
import type { ButtonProps } from 'naive-ui/lib/button';
import { propTypes } from '@/utils/propTypes';
export const basicProps = {
  
  labelWidth: {
    type: [Number, String] as PropType<number | string>,
    default: 80,
  },
  schemas: {
    type: [Array] as PropType<FormSchema[]>,
    default: () => [],
  },
  
  layout: {
    type: String,
    default: 'inline',
  },
  
  inline: {
    type: Boolean,
    default: false,
  },
  
  size: {
    type: String,
    default: 'medium',
  },
  
  labelPlacement: {
    type: String,
    default: 'left',
  },
  
  isFull: {
    type: Boolean,
    default: true,
  },
  
  showActionButtonGroup: propTypes.bool.def(true),
  
  showResetButton: propTypes.bool.def(true),

  resetButtonOptions: Object as PropType<Partial<ButtonProps>>,
 
  showSubmitButton: propTypes.bool.def(true),
  
  submitButtonOptions: Object as PropType<Partial<ButtonProps>>,
 
  showAdvancedButton: propTypes.bool.def(true),
  
  submitButtonText: {
    type: String,
    default: 'Search',
  },
  
  resetButtonText: {
    type: String,
    default: 'Reset',
  },
  
  gridProps: Object as PropType<GridProps>,
 
  giProps: Object as PropType<GridItemProps>,
  
  baseGridStyle: {
    type: Object as PropType<CSSProperties>,
  },
  
  collapsed: {
    type: Boolean,
    default: false,
  },
  
  collapsedRows: {
    type: Number,
    default: 1,
  },
};
