import AppProvider from './Application.vue';

export { AppProvider };
