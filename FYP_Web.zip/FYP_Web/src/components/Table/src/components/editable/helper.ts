import { ComponentType } from '../../types/componentType';

/**
 * @description: gen place holder
 */
export function createPlaceholderMessage(component: ComponentType) {
  if (component === 'NInput') return 'Enter';
  if (
    ['NPicker', 'NSelect', 'NCheckbox', 'NRadio', 'NSwitch', 'NDatePicker', 'NTimePicker'].includes(
      component
    )
  )
    return 'Choose';
  return '';
}
