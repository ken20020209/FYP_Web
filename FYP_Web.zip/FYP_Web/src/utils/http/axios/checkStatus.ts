export function checkStatus(status: number, msg: string): void {
  const $message = window['$message'];
  switch (status) {
    case 400:
      $message.error(msg);
      break;
  
    case 401:
      $message.error('User has no authority!');
      break;
    case 403:
      $message.error('Not allow to read!');
      break;
   
    case 404:
      $message.error('Error! No resources');
      break;
    case 405:
      $message.error('Error, Please get permission!');
      break;
    case 408:
      $message.error('Overtime');
      break;
    case 500:
      $message.error('Server Error , please find admin!');
      break;
    case 501:
      $message.error('Error');
      break;
    case 502:
      $message.error('Network error');
      break;
    case 503:
      $message.error('Server Stoped, server overrun or fixing!');
      break;
    case 504:
      $message.error('Network overtime');
      break;
    case 505:
      $message.error('http version not supported!');
      break;
    default:
      $message.error(msg);
  }
}
