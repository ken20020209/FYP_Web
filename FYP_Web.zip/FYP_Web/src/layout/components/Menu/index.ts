import AsideMenu from './index.vue';

export { AsideMenu };
