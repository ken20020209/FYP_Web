import PageHeader from './index.vue';

export { PageHeader };
