<template>
  <n-grid cols="1" responsive="screen" class="-mt-4">
    <n-grid-item>
      <n-list>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Change</n-button>
          </template>
          <n-thing title="Account">
            <template #description
              ><span class="text-gray-400">Set your phone number or email for safty</span></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Change</n-button>
          </template>
          <n-thing title="Set Phone">
            <template #description
              ><span class="text-gray-400">Phone number set:Your number is xxxxxxxx</span></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Setting</n-button>
          </template>
          <n-thing title="Password security quest">
            <template #description
              ><span class="text-gray-400"
                >PSQ havent set, security is not safe</span
              ></template
            >
          </n-thing>
        </n-list-item>
        <n-list-item>
          <template #suffix>
            <n-button type="primary" text>Change</n-button>
          </template>
          <n-thing title="Host Name">
            <template #description
              ><span class="text-gray-400">Set：https://www.naiveui.com</span></template
            >
          </n-thing>
        </n-list-item>
      </n-list>
    </n-grid-item>
  </n-grid>
</template>

<script lang="ts" setup></script>
