<template>
  <div>
    <n-grid :x-gap="24">
      <n-grid-item span="6">
        <section class="topButton">
          <n-button type="primary">
            display by group
          </n-button>
          <n-button type="primary">
            sort
          </n-button>
          <n-button type="primary">
            fifter
          </n-button>
        </section>

        

      </n-grid-item>
      <n-grid-item span="24">
        <div class="flexList">
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
                <p>date time</p>
                <p>
                  name
                </p>
              </div>
            </n-card>
          </div>
        </div>

        

      </n-grid-item>
      
    </n-grid>
  </div>
</template>
<script lang="ts" setup>




</script>
<style lang="less" scoped>
.topButton {
  display: flex;

  button {
    margin: 10px;
  }
}
.flexList {
  display: flex;
  flex-wrap: wrap;
  margin: 10px;
  justify-content: space-between;
  .item {
    text-align: center;
    width: 23%;
    margin: 20px 0;
    p {
      margin: 10px 0;
    }
    .desc  {
      display: flex;
      justify-content: space-between;
    }
  }
}
</style>
