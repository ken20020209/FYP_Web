<template>
  <n-grid cols="2 s:2 m:2 l:3 xl:3 2xl:3" responsive="screen">
    <n-grid-item>
      <n-form :label-width="80" :model="formValue" :rules="rules" ref="formRef">
        <n-form-item label="Web name" path="name">
          <n-input v-model:value="formValue.name" placeholder="Enter web name" />
        </n-form-item>

        <n-form-item label="icpCode" path="icpCode">
          <n-input placeholder="Enter icpcode" v-model:value="formValue.icpCode" />
        </n-form-item>

        <n-form-item label="mobile" path="mobile">
          <n-input placeholder="Enter mobile" v-model:value="formValue.mobile" />
        </n-form-item>

        <n-form-item label="address" path="address">
          <n-input v-model:value="formValue.address" type="textarea" placeholder="Enter address" />
        </n-form-item>

        <n-form-item label="loginCode" path="loginCode">
          <n-radio-group v-model:value="formValue.loginCode" name="loginCode">
            <n-space>
              <n-radio :value="1">ON</n-radio>
              <n-radio :value="0">Off</n-radio>
            </n-space>
          </n-radio-group>
        </n-form-item>

        <n-form-item label="systemOpen" path="systemOpen">
          <n-switch
            size="large"
            v-model:value="formValue.systemOpen"
            @update:value="systemOpenChange"
          />
        </n-form-item>

        <n-form-item label="closeText" path="closeText">
          <n-input
            v-model:value="formValue.closeText"
            type="textarea"
            placeholder="closeText"
          />
        </n-form-item>

        <div>
          <n-space>
            <n-button type="primary" @click="formSubmit">Submit</n-button>
          </n-space>
        </div>
      </n-form>
    </n-grid-item>
  </n-grid>
</template>

<script lang="ts">
  import { defineComponent, reactive, ref, toRefs } from 'vue';
  import { useDialog, useMessage } from 'naive-ui';

  const rules = {
    name: {
      required: true,
      message: 'Enter Webname',
      trigger: 'blur',
    },
    mobile: {
      required: true,
      message: 'Enter Moblie',
      trigger: 'input',
    },
  };

  export default defineComponent({
    setup() {
      const formRef: any = ref(null);
      const message = useMessage();
      const dialog = useDialog();

      const state = reactive({
        formValue: {
          name: '',
          mobile: '',
          icpCode: '',
          address: '',
          loginCode: 0,
          closeText:
            'We are fixing , please wait until we finish',
          systemOpen: true,
        },
      });

      function systemOpenChange(value) {
        if (!value) {
          dialog.warning({
            title: 'Reminder',
            content: 'Are you sure?！',
            positiveText: 'Confirm',
            negativeText: 'Cancel',
            onPositiveClick: () => {
              message.success('Success');
            },
            onNegativeClick: () => {
              state.formValue.systemOpen = true;
            },
          });
        }
      }

      function formSubmit() {
        formRef.value.validate((errors) => {
          if (!errors) {
            message.success('Success');
          } else {
            message.error('Failed , please enter complete form');
          }
        });
      }

      function resetForm() {
        formRef.value.restoreValidation();
      }

      return {
        formRef,
        ...toRefs(state),
        rules,
        formSubmit,
        resetForm,
        systemOpenChange,
      };
    },
  });
</script>
