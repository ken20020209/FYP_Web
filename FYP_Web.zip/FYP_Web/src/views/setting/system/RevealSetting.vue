<template>
  <n-grid cols="2 s:2 m:2 l:3 xl:3 2xl:3" responsive="screen">
    <n-grid-item>
      <n-form :label-width="120" :model="formValue" :rules="rules" ref="formRef">
        <n-form-item label="picture">
          <n-space align="center">
            <span>width：</span>
            <n-input
              v-model:value="formValue.bigWidth"
              style="width: 80px"
              placeholder="Width pixel"
            />
            <span>high：</span>
            <n-input
              v-model:value="formValue.bigHeight"
              style="width: 80px"
              placeholder="High pixel"
            />
          </n-space>
        </n-form-item>

        <n-form-item label="size">
          <n-space align="center">
            <span>width：</span>
            <n-input
              v-model:value="formValue.smallWidth"
              style="width: 80px"
              placeholder="width pixel"
            />
            <span>high：</span>
            <n-input
              v-model:value="formValue.smallHeight"
              style="width: 80px"
              placeholder="High pixel"
            />
          </n-space>
        </n-form-item>

        <n-form-item label="watermarkClarity" path="watermarkClarity">
          <n-input-number
            v-model:value="formValue.watermarkClarity"
            :show-button="false"
            placeholder="watermarkClarity"
          />
        </n-form-item>

        <n-form-item label="watermarkClarity" path="watermarkClarity">
          <n-upload action="http://www.mocky.io/v2/5e4bafc63100007100d8b70f">
            <n-button>Upload</n-button>
          </n-upload>
        </n-form-item>

        <n-form-item label="watermarkPlace" path="watermarkPlace">
          <n-select
            placeholder="watermarkPlace"
            :options="watermarkPlaceList"
            v-model:value="formValue.watermarkPlace"
          />
        </n-form-item>

        <n-form-item label="pricePreciseNum" path="pricePreciseNum">
          <n-select
            placeholder="pricePreciseNum"
            :options="pricePreciseNumList"
            v-model:value="formValue.pricePreciseNum"
          />
        </n-form-item>

        <n-form-item label="pricePrecise" path="pricePrecise">
          <n-select
            placeholder="pricePrecise"
            :options="pricePreciseList"
            v-model:value="formValue.pricePrecise"
          />
        </n-form-item>

        <n-form-item label="isMarketPric" path="isMarketPrice">
          <n-switch size="large" v-model:value="formValue.isMarketPrice" />
        </n-form-item>

        <div>
          <n-space>
            <n-button type="primary" @click="formSubmit">Update Information</n-button>
          </n-space>
        </div>
      </n-form>
    </n-grid-item>
  </n-grid>
</template>

<script lang="ts">
  import { defineComponent, reactive, ref, toRefs } from 'vue';
  import { useDialog, useMessage } from 'naive-ui';

  const rules = {
    name: {
      required: true,
      message: 'Enter title',
      trigger: 'blur',
    },
    mobile: {
      required: true,
      message: 'Enter phone number',
      trigger: 'input',
    },
  };
  const watermarkPlaceList = [
    {
      label: 'top left',
      value: 1,
    },
    {
      label: 'top right',
      value: 2,
    },
    {
      label: 'middle',
      value: 3,
    },
    {
      label: 'bottom right',
      value: 4,
    },
  ];

  const pricePreciseNumList = [
    {
      label: '2 digit',
      value: 1,
    },
    {
      label: '3 digit',
      value: 2,
    },
    {
      label: '4 digit',
      value: 3,
    },
  ];
  const pricePreciseList = [
    {
      label: '',
      value: 1,
    },
    {
      label: '',
      value: 2,
    },
    {
      label: '',
      value: 3,
    },
  ];

  export default defineComponent({
    setup() {
      const formRef: any = ref(null);
      const message = useMessage();
      const dialog = useDialog();

      const state = reactive({
        formValue: {
          bigWidth: '',
          bigHeight: '',
          smallWidth: '',
          smallHeight: '',
          watermarkClarity: null,
          pricePrecise: 1,
          isMarketPrice: true,
          pricePreciseNum: null,
        },
      });

      function systemOpenChange(value) {
        if (!value) {
          dialog.warning({
            title: 'Reminder',
            content: 'Are you sure you want to shut down the systme?',
            positiveText: 'Confirm',
            negativeText: 'Cancel',
            onPositiveClick: () => {
              message.success('Success');
            },
            onNegativeClick: () => {
              state.formValue.systemOpen = true;
            },
          });
        }
      }

      function formSubmit() {
        formRef.value.validate((errors) => {
          if (!errors) {
            message.success('Success');
          } else {
            message.error('Fail,Please fill with complete form');
          }
        });
      }

      function resetForm() {
        formRef.value.restoreValidation();
      }

      return {
        formRef,
        ...toRefs(state),
        pricePreciseList,
        watermarkPlaceList,
        pricePreciseNumList,
        rules,
        formSubmit,
        resetForm,
        systemOpenChange,
      };
    },
  });
</script>
