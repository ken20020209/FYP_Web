<template>
  <n-grid cols="2 s:2 m:2 l:3 xl:3 2xl:3" responsive="screen">
    <n-grid-item>
      <n-form :label-width="120" :model="formValue" :rules="rules" ref="formRef">
        <n-form-item label="originator" path="originator">
          <n-input v-model:value="formValue.originator" placeholder="originator" />
        </n-form-item>

        <n-form-item label="SMTP ip">
          <n-input placeholder="Enter SMTP ip" />
        </n-form-item>

        <n-form-item label="SMTP Sever">
          <n-input placeholder="Enter SMTP server" />
        </n-form-item>

        <n-form-item label="SMTP name">
          <n-input placeholder="Enter SMTP name" />
        </n-form-item>

        <n-form-item label="SMTP password">
          <n-input type="password" placeholder="Enter SMTP password" />
        </n-form-item>

        <n-form-item label="Email verification">
          <n-button>Email verification</n-button>
        </n-form-item>

        <div>
          <n-space>
            <n-button type="primary" @click="formSubmit">update email</n-button>
          </n-space>
        </div>
      </n-form>
    </n-grid-item>
  </n-grid>
</template>

<script lang="ts">
  import { defineComponent, reactive, ref, toRefs } from 'vue';
  import { useMessage } from 'naive-ui';

  const rules = {
    originator: {
      required: true,
      message: 'Enter originator',
      trigger: 'blur',
    },
  };
  export default defineComponent({
    setup() {
      const formRef: any = ref(null);
      const message = useMessage();

      const state = reactive({
        formValue: {
          originator: '',
        },
      });

      function formSubmit() {
        formRef.value.validate((errors) => {
          if (!errors) {
            message.success('Success');
          } else {
            message.error('Failed , please enter the complete form');
          }
        });
      }

      return {
        formRef,
        ...toRefs(state),
        rules,
        formSubmit,
      };
    },
  });
</script>
