<template>
  <div>Monitor</div>
</template>

<script lang="ts" setup></script>

<style lang="less" scoped></style>
