<template>
  <n-space>


    <n-grid :x-gap="24">
      <n-grid-item span="21">
        <n-button secondary strong>
          <template #icon>
            <n-icon size="30">
              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512">
                <path d="M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192s192-86 192-192z" fill="none"
                  stroke="currentColor" stroke-miterlimit="10" stroke-width="32"></path>
                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"
                  d="M256 176v160"></path>
                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"
                  d="M336 256H176"></path>
              </svg>
            </n-icon>
          </template>
          create Group
        </n-button>
        <n-button secondary strong>
          <template #icon>
            <n-icon size="30">
              <svg t="1709320374306" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
                p-id="4255" width="200" height="200">
                <path
                  d="M512 938.666667c235.637333 0 426.666667-191.029333 426.666667-426.666667S747.637333 85.333333 512 85.333333 85.333333 276.362667 85.333333 512s191.029333 426.666667 426.666667 426.666667zM352 480h320a32 32 0 0 1 0 64H352a32 32 0 0 1 0-64z"
                  fill="#000000" p-id="4256"></path>
              </svg>
            </n-icon>
          </template>
          create Group
        </n-button>



      </n-grid-item>

      <n-grid-item span="3">
        <!-- <img src="~@/assets/images/cmd.jpg"> -->
        <img src="~@/assets/images/1.png " alt="">
      </n-grid-item>

      <n-grid-item span="24">
        <div class="flexList">
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          <div class="item">
            <p>RobotDog ID</p>
            <n-card title="" size="small">
              <template #cover>
                <img src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg">
              </template>
              <div class="desc">
               <div class="bottom">
                <div class="select"> <n-select v-model:value="value" :options="options" /></div>
                <n-switch checked-value="0" unchecked-value="1"  />
               </div>
              </div>
            </n-card>
          </div>
          
        </div>



      </n-grid-item>

    </n-grid>



  </n-space>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'

export default defineComponent({
  setup() {
    return {
      value: ref(null),
      options: [

        {
          label: 'Drive My Car',
          value: 'song1'
        },
        {
          label: 'Norwegian Wood',
          value: 'song2'
        }
      ]
    }
  }
})
</script>
<style lang="less">
.topButton {
  display: flex;

  button {
    margin: 10px;
  }
}

.flexList {
  display: flex;
  flex-wrap: wrap;
  margin: 10px;
  justify-content: space-between;

  .item {
    text-align: center;
    width: 23%;
    margin: 20px 0;

    p {
      margin: 10px 0;
    }

    .desc {
      display: flex;
      justify-content: space-between;
    }
  }
}
.bottom {
  display: flex;align-items: center;justify-content: space-between;width: 100%;margin: 5px;
  .select {
    width: 120px;
  }
}
</style>