import { h } from 'vue';
import { NTag } from 'naive-ui';

export const columns = [
  {
    title: 'id',
    key: 'id',
  },
  {
    title: 'character_name',
    key: 'name',
  },
  {
    title: 'description',
    key: 'explain',
  },
  {
    title: 'isDefaultCharacter',
    key: 'isDefault',
    render(row) {
      return h(
        NTag,
        {
          type: row.isDefault ? 'success' : 'error',
        },
        {
          default: () => (row.isDefault ? 'yes' : 'no'),
        }
      );
    },
  },
  {
    title: 'createTime',
    key: 'create_date',
  },
];
