<template>
  <n-grid :x-gap="24">
    <n-grid-item :span="24">
      <h1 style="font-weight: bold;">Search</h1>
    </n-grid-item>
    <n-grid-item span="8">
      <section class="item">
        <span> UserName </span> <n-select v-model:value="value" :options="options"
          placeholder="please Enter the UserName" />
      </section>
    </n-grid-item>

    <n-grid-item span="8">
      <section class="item">
        <span> Sex </span> <n-select v-model:value="value" :options="options" placeholder="please Enter the Sex" />
      </section>
    </n-grid-item>
    <n-grid-item span="8">
      <section class="item">
        <span> NickName </span> <n-select v-model:value="value" :options="options"
          placeholder="please Enter the NickName" />
      </section>
    </n-grid-item>
    <n-grid-item span="8">
      <section class="item">
        <span> Telephone </span> <n-select v-model:value="value" :options="options"
          placeholder="please Enter the Telephone" />
      </section>
    </n-grid-item>
    <n-grid-item span="8">
      <section class="item">
        <span>Email </span> <n-select v-model:value="value" :options="options" placeholder="please Enter the Email" />
      </section>
    </n-grid-item>
    <n-grid-item span="8">
      <section class="item">
        <span>UserStatus</span> <n-select v-model:value="value" :options="options"
          placeholder="please Enter the UserStatus" />
      </section>
    </n-grid-item>


    <n-grid-item :span="24">
     
      <h1 style="font-weight: bold;"> UserList</h1>
    </n-grid-item>
    <n-grid-item :span="24">
      <n-data-table :columns="columns" :data="data" :pagination="pagination" :bordered="false" />
    </n-grid-item>
    <n-grid-item :span="12">
     
    </n-grid-item>
    <n-grid-item :span="6">
      <n-pagination v-model:page="page" :page-count="100" />
    </n-grid-item>
    
  


  </n-grid>
</template>

<script lang="ts">
import { defineComponent, ref,h } from 'vue'
import { NButton, useMessage,NTag } from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'

type Song = {
  id: number
  UserName: string
  Sex: string
  NickName:string
  Telephone:string
  Email:string
  UserStatus:string
}



const createColumns = ({
  edit,
  del
}: {
  edit: (row: Song) => void,
  del: (row: Song) => void
}): DataTableColumns<Song> => {
  return [
    {
      title: 'id',
      key: 'id'
    },
    {
      title: 'UserName',
      key: 'UserName'
    },
    {
      title: 'Sex',
      key: 'Sex',
      render (row) {
        console.log('Sex value:', row.Sex);
        return  h('div', { style: { display: 'flex', gap: '8px' } }, [
        h(
            NTag,
            {
              type: row.Sex === 'Male' ? 'primary' : 'warning',
            
              onClick: () => edit(row)
            },
            { default: () => row.Sex }
          )
        ])
      }
    },
    {
      title: 'NickName',
      key: 'NickName'
    },
    {
      title: 'Telephone',
      key: 'Telephone'
    },
    {
      title: 'Email',
      key: 'Email'
    },
    {
      title: 'UserStatus',
      key: 'UserStatus'
    },
    {
      title: 'Action',
      key: 'actions',
      render (row) {
        return  h('div', { style: { display: 'flex', gap: '8px' } }, [
        h(
            NTag,
            {
              type: 'primary', // Set button type to primary
            
              onClick: () => edit(row)
            },
            { default: () => 'Edit' }
          ),
          h(
            NTag,
            {
              type: 'warning', // Set button type to primary
              onClick: () => del(row)
            },
            { default: () => 'Delete' }
          )
        ])
      }
    }
  ]
}


const data: Song[] = [
  { id: 3, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
  { id: 4, UserName: 'Wonderwall', Sex: 'Female',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'fotbid' },
  { id: 5, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
  { id: 6, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
  { id: 7, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
  { id: 8, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
  { id: 9, UserName: 'Wonderwall', Sex: 'Male',NickName:'john',Telephone:'11111',Email:'123@com',UserStatus:'forbid' },
]
export default defineComponent({
  setup() {
  const message = useMessage()
  return {
    data,
    columns: createColumns({
      edit(row: Song) {
        message.info(`Edit ${row.UserName}`)
      },
      del(row: Song) {
        message.info(`Delete ${row.UserName}`)
      }
    }),
    pagination: false as const,
    value: ref(null),
    options: [
      {
        label: 'Drive My Car',
        value: 'song1'
      },
      {
        label: 'idrwegian Wood',
        value: 'song2'
      }
    ]
  }
}
})
</script>
<style lang="less" scoped>
.item {
  display: flex;
  margin: 10px;
  align-items: center;

  span {
    min-width: 60px;
    padding-right: 30px;
    display: inline-block;
  }
}
</style>