<template>
  <div>
    <div class="n-layout-page-header">
      <n-card :bordered="false" title="basicDesc"> basicDesc </n-card>
    </div>
    
  </div>
</template>

<script>
  import { defineComponent } from 'vue';

  export default defineComponent({
    setup() {
      return {};
    },
  });
</script>

<style lang="less" scoped></style>
