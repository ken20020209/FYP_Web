<template>
  <div>
    <n-grid :x-gap="24">
      <n-grid-item span="6">
        <section class="topButton">
          <n-button type="primary">
            exit
          </n-button>
          <div class="buttonList">
            <n-button type="primary">
              dog1
            </n-button>
            <n-button type="primary">
              dog2
            </n-button>
            <n-button type="primary">
              dog3
            </n-button>
            <n-button type="primary">
              dog4
            </n-button>
            <n-button type="primary">
              dog5
            </n-button>
          </div>
          <img src="~@/assets/images/controls1.jpg" alt="">
        </section>




      </n-grid-item>


      <n-grid-item span="12">
        <div class="list">
          <n-button type="primary">
            cam
          </n-button>
          <n-button type="primary">
           Map
          </n-button>
          <n-button >
            Current Status
          </n-button>
          <n-select v-model:value="value" :options="options" placeholder="effect of cam" />
        </div>

        <div class="cartList">
          <n-card >
            card
          </n-card>
          <n-card >
            card
          </n-card>
          <n-card >
            card
          </n-card>
          <n-card >
            card
          </n-card>
        </div>


      </n-grid-item>


      <n-grid-item span="6">
        <section class="topButton">
          <div class="imgList">
            <img src="~@/assets/images/voice1.jpg" alt="">
            <img src="~@/assets/images/m1.jpg" alt="">
          </div>
          <div class="buttonList buttonList2">
            <n-button type="primary">
             action1
            </n-button>
            <n-button type="primary">
              action2
            </n-button>
            <n-button type="primary">
              action3
            </n-button>
            <n-button type="primary">
              action4
            </n-button>
            <n-button type="primary">
              action5
            </n-button>
          </div>
          <img src="~@/assets/images/controls1.jpg" alt="">
        </section>




      </n-grid-item>


    </n-grid>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue'

export default defineComponent({
  setup() {
    return {
      value: ref(null),
      options: [

        {
          label: 'Drive My Car',
          value: 'song1'
        },
        {
          label: 'Norwegian Wood',
          value: 'song2'
        },
        {
          label: 'Nowhere Man',
          value: 'song4'
        },
        {
          label: 'Think For Yourself',
          value: 'song5'
        }
      ]
    }
  }
})
</script>
<style lang="less" scoped>
.topButton {
  display: flex;
  flex-direction: column;
  align-items: center;

  button {
    margin: 10px;
  }
}

.buttonList {
  display: flex;
  flex-direction: column;
  align-items: left;
  text-align: left;
  width: 100%;
  margin: 30px 0;

  button {
    width: 30%;
    margin: 10px;
  }

}
.buttonList2 {
  align-items: flex-end;
}

.list {
  display: flex;
  margin-top: 10px;
  // width: 80%;
  button {
    width: 20%;
    margin: 0 10px;
  }

  select {
    width: 100px;
    margin: 10px;
  }
  
}
.cartList {
  display: flex;
  justify-content: space-between;
  min-height: 500px;
  flex-wrap: wrap;
  // margin: 20px;
}

/deep/.n-card {
    width: 45%;
    margin: 10px;
  }
  .imgList {
    width: 34px;
    display: flex;
    img {
      margin: 0 10px;
    }
  }
  </style>
