import { h } from 'vue';
import { NAvatar } from 'naive-ui';
import { BasicColumn } from '@/components/Table';
export interface ListData {
  id: string;
  name: string;
  avatar: string;
  address: string;
  beginTime: string;
  endTime: string;
  date: string;
}
export const columns: BasicColumn<ListData>[] = [
  {
    title: 'id',
    key: 'id',
    width: 100,
  },
  {
    title: 'name',
    key: 'name',
    width: 100,
  },
  {
    title: 'Icon',
    key: 'avatar',
    width: 100,
    render(row) {
      return h(NAvatar, {
        size: 48,
        src: row.avatar,
      });
    },
  },
  {
    title: 'address',
    key: 'address',
    auth: ['basic_list'], 
    ifShow: (_column) => {
      return true;
    },
    width: 150,
  },
  {
    title: 'beginTime',
    key: 'beginTime',
    width: 160,
  },
  {
    title: 'endTime',
    key: 'endTime',
    width: 160,
  },
  {
    title: 'date',
    key: 'date',
    width: 100,
  },
];
