
export function setupGlobalMethods() {}
