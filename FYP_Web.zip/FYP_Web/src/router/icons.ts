import { renderIcon } from '@/utils/index';
import { DashboardOutlined } from '@vicons/antd';


export const constantRouterIcon = {
  DashboardOutlined: renderIcon(DashboardOutlined),
};
