export interface ProjectSettingState {

  navMode: string;

  navTheme: string;

  headerSetting: object;

  showFooter: boolean;

  menuSetting: object;

  multiTabsSetting: object;

  crumbsSetting: object;

  permissionMode: string;
}

export interface IBodySetting {
  fixed: boolean;
}

export interface IHeaderSetting {
  bgColor: string;
  fixed: boolean;
  isReload: boolean;
}

export interface IMenuSetting {
  minMenuWidth: number;
  menuWidth: number;
  fixed: boolean;
  mixMenu: boolean;
  collapsed: boolean;
  mobileWidth: number;
}

export interface ICrumbsSetting {
  show: boolean;
  showIcon: boolean;
}

export interface IMultiTabsSetting {
  bgColor: string;
  fixed: boolean;
  show: boolean;
}
export interface GlobConfig {
  title: string;
  apiUrl: string;
  shortName: string;
  urlPrefix?: string;
  uploadUrl?: string;
  prodMock: boolean;
  imgUrl?: string;
}

export interface GlobEnvConfig {

  VITE_GLOB_APP_TITLE: string;

  VITE_GLOB_API_URL: string;

  VITE_GLOB_API_URL_PREFIX?: string;

  VITE_GLOB_APP_SHORT_NAME: string;

  VITE_GLOB_UPLOAD_URL?: string;

  VITE_GLOB_IMG_URL?: string;

  VITE_GLOB_PROD_MOCK: boolean;
}
